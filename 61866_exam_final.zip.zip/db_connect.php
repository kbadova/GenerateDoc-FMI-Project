<?php
$servername = "localhost";
$port = "3306";
$username = "root";
$password = "kbadova159";
$dbname = "myDb";
?>