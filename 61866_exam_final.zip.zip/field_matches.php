<?php
$field_matches = array(
    'has_resources' => 'Използвани източници',
    'has_learned' => 'Какво научих',
    'has_contribution' => 'Приноси на студента, ограничения и възможности за бъдещо разширение',
    'has_description' => 'Описание на програмния код',
    'has_example_data' => 'Примерни данни',
    'has_guide' => 'Кратко ръководство на потребителя',
    'has_settings' => 'Инсталация и настройки',
    'has_technologies' => 'Използвани технологии',
    'has_introduction' => 'Въведение',
    'has_my_condition' => 'Условие',
    'has_theory' => 'Теория');
?>