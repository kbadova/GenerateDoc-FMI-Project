<form method="POST">
  <p>
    <label>1. Условие</label>
    <input type="checkbox" name="has_my_condition" value="1">
  </p>
  <p>
    <label>2. Въведение</label>
    <input type="checkbox" name="has_introduction" value="1">
  </p>
  <p>
    <label>3. Теория</label>
    <input type="checkbox" name="has_theory" value="1">
  </p>
  <p>
    <label>4. Използвани технологии</label>
    <input type="checkbox" name="has_technologies" value="1">
  </p>
  <p>
    <label>5. Инсталация и настройки</label>
    <input type="checkbox" name="has_settings" value="1">
  </p>
  <p>
    <label>6. Кратко ръководство на потребителя</label>
    <input type="checkbox" name="has_guide" value="1">
  </p>
  <p>
    <label>7. Примерни данни</label>
    <input type="checkbox" name="has_example_data" value="1">
  </p>
  <p>
    <label>8. Описание на програмния код</label>
    <input type="checkbox" name=" has_description" value="1">
  </p>
  <p>
    <label>9. Приноси на студента, ограничения и възможности за бъдещо разширение</label>
    <input type="checkbox" name="has_contribution" value="1">
  </p>
  <p>
    <label>10. Какво научих</label>
    <input type="checkbox" name="has_learned" value="1">
  </p>
  <p>
    <label>11. Използвани източници</label>
    <input type="checkbox" name="has_resources" value="1">
  </p>
  <input type="submit" class="btn green" style="display: inline" value="Генерирай">
</form>